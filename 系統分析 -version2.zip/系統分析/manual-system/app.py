import os
import logging
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL

app = Flask(__name__)

# Configure MySQL connection settings
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  # Your MySQL username
app.config['MYSQL_PASSWORD'] = '1234'  # Your MySQL password
app.config['MYSQL_DB'] = 'human'  # The name of your database
app.secret_key = 'your_secret_key'  # Secret key for session management

# Initialize the MySQL extension
mysql = MySQL(app)

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Check the connection to the database before processing the first request
@app.before_request
def check_database_connection():
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT 1')  # A simple query to test the connection
        cur.close()
        logger.info("Connected to the MySQL database successfully!")
    except Exception as e:
        logger.error(f"Error connecting to the database: {e}")

# Route to render index.html as the main page (login page)
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle the login logic
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT id, password_hash FROM userlogin WHERE username = %s', [username])
        user = cur.fetchone()
        cur.close()

        if user and user[1] == password:
            session['user_id'] = user[0]
            session['username'] = username
            return redirect(url_for('caseview'))
        else:
            return "Invalid username or password", 401
    except Exception as e:
        logger.error(f"Login error: {e}")
        return "An error occurred", 500

# Route to render caseview.html (after login)
@app.route('/caseview')
def caseview():
    if 'user_id' not in session:
        return redirect(url_for('index'))

    try:
        user_id = session.get('user_id')
        cur = mysql.connection.cursor()
        cur.execute('SELECT violation_id, image_path, camera_id, status, remarks FROM violations')
        violations = cur.fetchall()
        cur.execute('SELECT username FROM userlogin WHERE id = %s', [user_id])
        user = cur.fetchone()
        cur.close()
        return render_template('caseview.html', violations=violations, processing_personnel=user[0])
    except Exception as e:
        logger.error(f"Caseview error: {e}")
        return "An error occurred", 500

# Route for casecheck
@app.route('/casecheck', methods=['GET', 'POST'])
def casecheck():
    if request.method == 'POST':
        try:
            manual_recognize_plate = request.form['manual_recognize_plate']
            violation_id = request.form.get('violation_id')

            # Update the manual recognition result and status
            user_id = session.get('user_id')
            cur = mysql.connection.cursor()
            cur.execute('INSERT INTO manual_recognition (id, manual_recognize_plate) VALUES (%s, %s)', 
                        (user_id, manual_recognize_plate))
            
            # Update the status to 'checked'
            cur.execute('UPDATE violations SET status = %s WHERE violation_id = %s', 
                        ('checked', violation_id))
            mysql.connection.commit()
            cur.close()

            # Redirect back to caseview
            return redirect(url_for('caseview'))  
        except Exception as e:
            logger.error(f"Casecheck error: {e}")
            return "An error occurred", 500
    else:
        try:
            violation_id = request.args.get('violation_id')  # Get violation_id from URL parameters
            if violation_id:
                cur = mysql.connection.cursor()
                cur.execute('SELECT violation_id, image_path, camera_id, status, remarks FROM violations WHERE violation_id = %s', [violation_id])
                violation = cur.fetchone()  # Fetch the single violation based on violation_id
                cur.close()

                if violation:
                    return render_template('casecheck.html', violation=violation)
                else:
                    return "No violation found with ID {violation_id}", 404
            else:
                return "Violation ID is missing.", 400
        except Exception as e:
            logger.error(f"Casecheck GET error: {e}")
            return "An error occurred", 500

# Route for ticket generation
@app.route('/ticket/<int:violation_id>')
def ticket(violation_id):
    try:
        # Fetch the violation details from the database using violation_id
        cur = mysql.connection.cursor()
        cur.execute("""
            SELECT 
                violation_id, 
                license_plate, 
                driver_name, 
                gender, 
                driver_birth_date, 
                violation_time, 
                violation_location, 
                actual_speed, 
                speed_limit, 
                fine_amount, 
                violation_description, 
                image_path 
            FROM violations 
            WHERE violation_id = %s
        """, (violation_id,))
        violation = cur.fetchone()
        cur.close()

        if violation:
            return render_template('ticket.html', violation=violation)
        else:
            return "No violation found with ID {violation_id}", 404
    except Exception as e:
        logger.error(f"Ticket generation error: {e}")
        return "An error occurred", 500

if __name__ == '__main__':
    app.run(debug=True)
