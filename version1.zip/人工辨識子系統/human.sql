-- Drop the database if it exists
DROP DATABASE IF EXISTS human;

-- Create the database
CREATE DATABASE human;

-- Select the database
USE human;

-- Create the table with 'id' and 'name' columns
CREATE TABLE humantable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

-- Insert the record with 'id' = 1 and 'name' = 'Ying'
INSERT INTO humantable (id, name) 
VALUES (1, 'Ying');

CREATE TABLE violations (
    violation_id INT AUTO_INCREMENT PRIMARY KEY,
    location VARCHAR(255) NOT NULL,
    camera_id VARCHAR(50) NOT NULL,
    image_path VARCHAR(255),
    status ENUM('pending', 'processed') DEFAULT 'pending',
    remarks TEXT
);

INSERT INTO violations (violation_time, location, camera_id, image_path, status, remarks) 
VALUES 
('2024-12-30 14:30:00', 'Intersection A', 'CAM001', '/images/violation1.jpg', 'pending', 'Speeding vehicle');

