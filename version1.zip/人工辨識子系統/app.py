from flask import Flask, render_template
from flask_mysqldb import MySQL

app = Flask(__name__)

# Configure MySQL connection settings
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'  # Your MySQL username
app.config['MYSQL_PASSWORD'] = '1234'  # Your MySQL password
app.config['MYSQL_DB'] = 'human'  # The name of your database

# Initialize the MySQL extension
mysql = MySQL(app)

# Check the connection to the database before processing the first request
@app.before_request
def check_database_connection():
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT 1')  # A simple query to test the connection
        cur.close()
        print("Connected to the MySQL database successfully!")
    except Exception as e:
        print(f"Error connecting to the database: {e}")

# Route to render the caseview.html and populate the table
@app.route('/')
def caseview():
    try:
        # Create a cursor to execute SQL queries
        cur = mysql.connection.cursor()

        # Query the database to fetch data from `violations`
        cur.execute('SELECT violation_id, image_path, camera_id, status, remarks FROM violations')
        violations = cur.fetchall()  # Fetch all rows from the query result

        # Close the cursor
        cur.close()

        # Render the HTML template and pass the data
        return render_template('caseview.html', violations=violations)

    except Exception as e:
        return f"Error: {e}"

if __name__ == '__main__':
    app.run(debug=True)
